package com.csn.auto;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> chooser; private byte[] pending;
 public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);
 WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);
 Export export=new Export();
 web.addJavascriptInterface(export,"CSNAndroid");
 web.addJavascriptInterface(export,"AndroidReport");
 web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
 public void onPageFinished(WebView v,String u){v.evaluateJavascript("(()=>{const old=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.download&&this.href.startsWith('blob:')){const name=this.download;fetch(this.href).then(r=>r.blob()).then(b=>{const f=new FileReader();f.onload=()=>CSNAndroid.save(name,String(f.result).split(',')[1]);f.readAsDataURL(b)});return;}old.call(this)}})()",null);}});
 web.setWebChromeClient(new WebChromeClient(){public boolean onJsAlert(WebView v,String u,String message,JsResult result){new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK",(dialog,which)->result.confirm()).setCancelable(false).show();return true;}public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(chooser!=null)chooser.onReceiveValue(null);chooser=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);try{startActivityForResult(i,10);}catch(Exception e){chooser.onReceiveValue(null);chooser=null;}return true;}});
 web.loadUrl("file:///android_asset/index.html");}
 private void exportResult(boolean ok,String message){web.evaluateJavascript("if(typeof window.reportExportResult==='function'){window.reportExportResult("+ok+","+JSONObject.quote(message)+");}",null);}
 private void requestSave(String name,byte[] bytes){runOnUiThread(()->{
  if(pending!=null){Toast.makeText(MainActivity.this,"Terminez le premier enregistrement",Toast.LENGTH_LONG).show();return;}
  pending=bytes;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^a-zA-Z0-9._-]","_"));
  try{startActivityForResult(i,11);}catch(Exception e){pending=null;exportResult(false,"Enregistrement indisponible");}
 });}
 public class Export {
  @JavascriptInterface public void saveReport(String text,String filename){
   if(text==null||filename==null){runOnUiThread(()->exportResult(false,"Rapport ou nom de fichier absent"));return;}
   String utf8=text.startsWith("\uFEFF")?text:"\uFEFF"+text;
   requestSave(filename,utf8.getBytes(StandardCharsets.UTF_8));
  }
  @JavascriptInterface public void save(String name,String data){try{requestSave(name,Base64.decode(data,Base64.DEFAULT));}catch(Exception e){runOnUiThread(()->exportResult(false,"Échec du téléchargement"));}}
 }
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);
  if(r==10&&chooser!=null){chooser.onReceiveValue(c==RESULT_OK&&d!=null&&d.getData()!=null?new Uri[]{d.getData()}:null);chooser=null;}
  if(r==11){byte[] bytes=pending;pending=null;
   if(c!=RESULT_OK||d==null||d.getData()==null||bytes==null){Toast.makeText(this,"Enregistrement annulé",Toast.LENGTH_LONG).show();return;}
   try{try(OutputStream o=getContentResolver().openOutputStream(d.getData())){if(o==null)throw new java.io.IOException("Flux absent");o.write(bytes);}exportResult(true,"Fichier enregistré à l’emplacement choisi.");}catch(Exception e){exportResult(false,"Échec de l’enregistrement. Réessayez dans un autre dossier.");}
  }
 }
 public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
