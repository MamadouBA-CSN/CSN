# CSN 1.3 AUTO — Android

Projet Android natif minimal contenant CSN 1.3 AUTO dans une WebView locale.

## Fonctionnement
- application autonome et hors ligne ;
- aucune permission Internet demandée ;
- ouverture de CSN depuis une icône Android ;
- sélection d'un fichier via le sélecteur Android ;
- inspection automatique dès la sélection, comme dans CSN 1.3 AUTO.

## Construction
Le workflow GitHub Actions `.github/workflows/build-apk.yml` construit automatiquement un APK de test installable.

L'APK de test est signé avec la clé de débogage du service de compilation. Pour une diffusion commerciale définitive, une version release doit être signée avec une clé privée durable appartenant à l'éditeur.

© 2026 Mamadou BA. Tous droits réservés.
